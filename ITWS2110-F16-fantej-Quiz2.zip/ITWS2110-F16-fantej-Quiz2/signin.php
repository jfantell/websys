<?
	echo "You have been signed in to that class";
?>