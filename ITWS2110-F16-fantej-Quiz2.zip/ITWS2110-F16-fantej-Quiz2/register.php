<?php

session_start();
$_SESSION['err']='';

try {
	$servername = "localhost";
	$username = "root";
	$password = "";
    $dbconn = new PDO("mysql:host=$servername;dbname=ITWS2110-F16-yourRCSID-Quiz2", $username, $password);
    // set the PDO error mode to exception
    $dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully on register page"; 


    //Check to see if the register button was pressed
	if (isset($_POST['register']) && $_POST['register']=='Register') {

		// Check and make sure that all fields are filled out
		if (empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['username']) || 
			empty($_POST['password']) || empty($_POST['confirmPass'])) {
			$msg = "Please fill in all form fields";
		}
		//Make sure the passwords entered match
		else if ($_POST['password'] != $_POST['confirmPass']) {
			$msg = "Passwords must match.";
		}
		//Store the user's information in the database
		else {
			//Generate random salt
			$salt = hash('sha256', uniqid(mt_rand(), true));

			//Apply salt to password
			$salted = hash('sha256', $salt.$_POST['password']);

			//Store the salt and password together
			$stmt = $dbconn->prepare("INSERT INTO user (first_name, last_name, nickname, password, salt) 
				VALUES (:fname, :lname, :username, :password, :salt)");
			$stmt->execute(array(':fname' => $_POST['fname'], ':lname' => $_POST['lname'],
				':username' => $_POST['username'], ':password' => $salted,':salt' => $salt));
			$msg = "Account was created successfully!";

            // redirect user to survey page upon successful registration
            $_SESSION['username'] = $user['username'];
            $_SESSION['uid'] = $user['uid'];
            header("Location: class.php");
            exit();
		}
	}
} 
catch (Exception $e){
		echo "Error: " . $e->getMessage();
	}

?>

<html>
<head>
	<form method="post" action="register.php" class="form-signin">
        <!-- HTML form to allow the user to interact with the page  -->
        <h2 class="form-signin-heading">Sign-up here</h2>
        <label for="fname">First Name</label>
        <input type="text" name="fname" class="form-control" placeholder="First Name" required="" autofocus="">
        <label for="lname">Last Name</label>
        <input type="text" name="lname" class="form-control" placeholder="Last Name" required="">
        <label for="username">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Username" required="">
        <label for="password">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required="">
        <label for="confirmPass">Confirm Password</label>
        <input type="password" name="confirmPass" class="form-control" placeholder="Confirm Password" required="">
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="register" value="Register" role="button">Sign-up</a>
      </form>
</head>
</html>