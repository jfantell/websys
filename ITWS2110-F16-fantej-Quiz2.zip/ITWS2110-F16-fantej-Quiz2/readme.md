a. Use a PDO to install the database, create the relevant tables, and then insert or query the desired information.
b. If section administration is referring to user roles and permissions, I would create different roles for students, sysadmins, and instructors.
c. Using SQL function IGNORE (I.E. INSERT IGNORE)
d. Require a secret pin

Was not able to get everything working as I had hoped. But probably another 20 minutes to fix the bugs. Right now when a user types in the course they register it redirects them to signin.php. Fully functional it would insert the user into that course.