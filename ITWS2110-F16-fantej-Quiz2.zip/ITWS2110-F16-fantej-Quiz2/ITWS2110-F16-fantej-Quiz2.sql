-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2016 at 01:41 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ITWS2110-F16-yourRCSID-Quiz2`
--
CREATE DATABASE IF NOT EXISTS `ITWS2110-F16-yourRCSID-Quiz2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ITWS2110-F16-yourRCSID-Quiz2`;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `aid` int(11) NOT NULL,
  `course_prefix` varchar(10) NOT NULL,
  `username` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `cid` int(11) NOT NULL,
  `course_prefix` varchar(10) NOT NULL,
  `course_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`cid`, `course_prefix`, `course_name`) VALUES
(1, 'ITWS2110', 'Web Systems Development'),
(2, 'ITWS4500', 'Web Systems Science Development');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `nickname` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `username`, `first_name`, `last_name`, `nickname`, `password`, `salt`) VALUES
(4, '', 'jfantell', 'jfantell', 'jfantell', '51141abcfb0f278f8f5840d366fcd104eab4dc389f6b9b8c8c26f47a3076cdfb', '4c3f46b4a481f1470ae8f28aa16b2410680874e221c292c224bf67a95ddf8845'),
(5, '', 'jfantell', 'jfantell', 'jfantell', '2a674b9c27741915bdfd05bd36e47fb41debe57aa9bedf4614ff3acbfcfca019', 'c42efaaad57c44126d945e0c107167c996f90e755894e222c681775ca4c29dce'),
(6, '', 'j', 'j', 'j', '347fdf48f1f4b7ccafa255578a464521ad0173eeceb8a6301c47232e2d7f19ff', '17b890c9ef73f631754c769e99f97427a0a9d05941bc9a5e0a67b503e58d02a2'),
(7, '', 'j', 'j', 'j', '679498e0a6c67eabdc62b5a9373ba386356d380d8cb5ed1e0a273ff9575aa371', '044303e06e3f8f7fab2529ee42dd3d5a4cc64b495fdcdf6452730367c751bf9b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
