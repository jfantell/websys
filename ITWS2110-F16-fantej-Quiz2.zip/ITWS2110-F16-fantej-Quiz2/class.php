<?php

session_start();
$_SESSION['err']='';

try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbconn = new PDO("mysql:host=$servername;dbname=ITWS2110-F16-yourRCSID-Quiz2", $username, $password);
    // set the PDO error mode to exception
    $dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_SESSION['username']) && isset($_POST['register']) && $_POST['register'] == 'Register') {
        header("Location: signin.php")
    }

    if (isset($_SESSION['username']) && isset($_POST['logout']) && $_POST['logout'] == 'Logout') {
    // Destroy the session data store
    $_SESSION = array();

    // If it's desired to kill the session, also delete the session cookie.
    // Note: This will destroy the session, and not just the session data!
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_unset();
    session_destroy();
    $GLOBALS['msg'] = 'You have been logged out.';
    header("Location: index.php");
    exit();
  }
} 
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

?>

<html>
<head>
    <style>
        table, th {
            border: black solid 2px;
        }
    </style>
</head>
<body>

    <?php
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbconn = new PDO("mysql:host=$servername;dbname=ITWS2110-F16-yourRCSID-Quiz2", $username, $password);
        // set the PDO error mode to exception
        $dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $users = "SELECT * FROM `courses`";
        $out = $dbconn->prepare($users);
        $out->execute(array());
        echo '<table style="width:100%"><tr><th>Course Prefix</th> <th>Course Name</th></tr>';
        while ($row = $out->fetch()) {
            printf("<tr><th>%s</th> <th>%s</th></tr>",$row['course_prefix'],$row['course_name']);
        }
        echo '</table>';
    }
    catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    }
    ?>
    <form method="post" action="class.php">
            <label for="username">Enter the name of the class you would like to register for </label>
            <input type="text" name="course" class="form-control" placeholder="Enter Username" required=""/>
            <br>
            <button class="btn btn-lg btn-danger btn-block" type="submit" name="register" value="Register" role="button">Delete User</button>
    </form>
	<form action="class.php" method="post">
        <button class="btn btn-danger" name="logout" value="Logout" role="button">Sign-out</button>
    </form>
</body>
</html>