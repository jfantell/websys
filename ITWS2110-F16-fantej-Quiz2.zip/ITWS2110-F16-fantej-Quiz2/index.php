<?php

session_start();
$_SESSION['err']='';

try {
	$servername = "localhost";
	$username = "root";
	$password = "";
    $dbconn = new PDO("mysql:host=$servername;dbname=ITWS2110-F16-yourRCSID-Quiz2", $username, $password);
    // set the PDO error mode to exception
    $dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 

	//If the user clicks the login button
	if (isset($_POST['login']) && $_POST['login']=="Login"){


		//Define the salt statement based on the username
		$salt_stmt = $dbconn->prepare('SELECT salt from user WHERE username=:username');
		$salt_stmt->execute(array(':username' => $_POST['username']));
		$result = $salt_stmt->fetch();

		//Gets the salt statement that was originally used with the user's password
		$salt = ($result) ? $result['salt'] : '';

		//Obtain the salted password by combining the user's input with the salt and hash
		$salted = hash('sha256', $salt . $_POST['password']);

		//Check if username already in database
		$login_username = $dbconn->prepare('SELECT username, uid FROM user WHERE username=:username');
		$login_username->execute(array(':username' => $_POST['username']));

		//find the appropriate user in the database (username and password match and are in db)
		$login_stmt = $dbconn->prepare('SELECT username, uid FROM user WHERE username=:username AND password=:password');
		$login_stmt->execute(array(':username' => $_POST['username'], ':password' => $salted));

		//User entered valid credentials
		if ($user = $login_stmt->fetch()) {
			$_SESSION['username'] = $user['username'];
			$_SESSION['uid'] = $user['uid']; 
			$msg = 'Login successful';
			header("Location: class.php");
			exit();
		//User may have entered wrong password, username does exist
		} else if($user = $login_username->fetch()) {
			echo "Wrong password! Try again.";
		}
		//User does not exist
		else {
			//$_SESSION['err'] = 'Incorrect username or password.';
			header("Location: register.php");
			exit();
		}
	
	}
}
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

	
?>

<html>
<head>
<body>
	<form method="post" action="index.php">
        <label for="username">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Username" required="" autofocus="">
        <label for="password">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required="">
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="login" value="Login" role="button">Sign-in</button>
	</form>
</body>
</head>
</html>