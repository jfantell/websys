Fun lab. A little challenging at first to figure out how to connect all of the scripts, but definitely helped increase my understanding of PHP/MySQL.

-John