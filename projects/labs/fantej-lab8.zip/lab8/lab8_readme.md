The commands and output for questions 7-10 can be found in the word document "lab8sql_commands&outputs"

The overall structure of the SQL database (exported using phpmyadmin) is found in the document titled "websyslab8.sql"

Took a little time to figure out number 8 because I did not read through the PowerPoint slides thoroughly before starting the lab. However after consulting the slides it was fairly easy to figure out what to do. I imagine in the term project my team is working on SQL databases will play a very important role in sorting all of the product information we retrive.

Overall, good lab. Learned SQL basics!

-John 

Collaborators:

Adeel Minhas