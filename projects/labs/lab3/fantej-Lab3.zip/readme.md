Part 1: Recursive part was a bit tricky. Using various examples from W3schools and the provided code, I was able to patch the errors in the code I initially developed.

Part 2: Pretty straightforward. I am still not completely sure what the "false" at the end of the alert function does. Does that mean "return false"?

Part 3: Like the second part, fairly straightforward although the wording tripped me up a bit. But now it makes a lot of sense.

In a CSS file (lab3.css) I added borders to all of the elements with "quote" class and "info" id

Collaborators: 

Samm Katcher
